create function trigger_delivery_id() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO orders(delivery_id) VALUES (NEW.id);
    RETURN NEW;
END;
$$;

alter function trigger_delivery_id() owner to grandpat;

