create function trigger_payment_id() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO orders(payment_id) VALUES (NEW.id);
    RETURN NEW;
END;
$$;

alter function trigger_payment_id() owner to grandpat;

