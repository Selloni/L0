create function delivery_id() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO delivery (id) VALUES (NEW.id);
    RETURN NEW;
END;
$$;

alter function delivery_id() owner to grandpat;

